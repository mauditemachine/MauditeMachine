//go:build windows && !arm64
// +build windows,!arm64

//go:generate goversioninfo

package main
